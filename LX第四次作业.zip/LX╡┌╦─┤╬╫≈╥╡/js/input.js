function submit(e) {
    var formData = {
        name: uname.value,
        sex: sex.value,
        age: age.value
    };

    $.ajax({
        url: 'http://localhost:7777/input',
        type: 'post',
        data: formData,
        dataType: 'json',
        success: function (data) {
            if (data.code ===200){
                alert("Success!");
                console.log('密码错误');
            }
        },
        error: function (err) {
            console.log('请注册');
        }
    })

}

$(document).ready(function(e) {
    $('#submit').on('click', submit);
})
